package com.example.libapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
