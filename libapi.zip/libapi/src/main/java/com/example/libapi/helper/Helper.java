package com.example.libapi.helper;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.example.libapi.entity.Product;

public class Helper {

	public static boolean checkExcelFormat(MultipartFile file) {

		String contentType = file.getContentType();

		if (contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
			return true;
		} else {
			return false;
		}
	}

	public static List<Product> convertExcelToListOfProduct(InputStream is) {
		List<Product> list = new ArrayList<>();

		try {
			XSSFWorkbook workbook = new XSSFWorkbook(is);

			XSSFSheet sheet = workbook.getSheetAt(0); // Changed to get the first sheet

			int rowNumber = 0;
			Iterator<Row> iterator = sheet.iterator();

			while (iterator.hasNext()) {
				Row row = iterator.next();

				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}

				Iterator<Cell> cells = row.iterator();

				int cid = 0;
				Product p = new Product();

				while (cells.hasNext()) {
					Cell cell = cells.next();

					switch (cid) {
					case 0:
						p.setPositionId((int) cell.getNumericCellValue());
						break;
					case 1:
						p.setProductStatus(cell.getStringCellValue());
						break;
					case 2:
						// Assuming that the cell contains a valid date value
						p.setTimeIn(cell.getLocalDateTimeCellValue());
						break;
					case 3:
						p.setTimeOut(cell.getLocalDateTimeCellValue());
						break;
					case 4:
						// Assuming that the cell contains a valid date value for timecard hours
						p.setTimecardHours(cell.getLocalDateTimeCellValue());
						break;

					case 5:
						p.setPayCycleStartDate(cell.getDateCellValue());
						break;
					case 6:
						p.setPayCycleEndDate(cell.getDateCellValue());
						break;
					case 7:
						p.setEmployeeName(cell.getStringCellValue());
						break;
					case 8:
						p.setFileNumber((int) cell.getNumericCellValue());
						break;
					default:
						break;
					}

					cid++;
				}
				list.add(p);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
