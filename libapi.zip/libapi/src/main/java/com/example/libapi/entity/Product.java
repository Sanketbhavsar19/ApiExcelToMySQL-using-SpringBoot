package com.example.libapi.entity;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Product {

	@Id
	private Integer positionId;
	private String productStatus;
	private LocalDateTime timeIn;
	private LocalDateTime timeOut;
	private LocalDateTime timecardHours;
	private Date payCycleStartDate;
	private Date payCycleEndDate;
	private String employeeName;
	private Integer fileNumber;

	public Integer getPositionId() {
		return positionId;
	}

	public void setPositionId(Integer positionId) {
		this.positionId = positionId;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	public LocalDateTime getTimeIn() {
		return timeIn;
	}

	public void setTimeIn(LocalDateTime timeIn) {
		this.timeIn = timeIn;
	}

	public LocalDateTime getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(LocalDateTime timeOut) {
		this.timeOut = timeOut;
	}

	public LocalDateTime getTimecardHours() {
		return timecardHours;
	}

	public void setTimecardHours(LocalDateTime timecardHours) {
		this.timecardHours = timecardHours;
	}

	public Date getPayCycleStartDate() {
		return payCycleStartDate;
	}

	public void setPayCycleStartDate(Date payCycleStartDate) {
		this.payCycleStartDate = payCycleStartDate;
	}

	public Date getPayCycleEndDate() {
		return payCycleEndDate;
	}

	public void setPayCycleEndDate(Date payCycleEndDate) {
		this.payCycleEndDate = payCycleEndDate;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Integer getFileNumber() {
		return fileNumber;
	}

	public void setFileNumber(Integer fileNumber) {
		this.fileNumber = fileNumber;
	}

	public Product(Integer positionId, String productStatus, LocalDateTime timeIn, LocalDateTime timeOut,
			LocalDateTime timecardHours, Date payCycleStartDate, Date payCycleEndDate, String employeeName,
			Integer fileNumber) {
		super();
		this.positionId = positionId;
		this.productStatus = productStatus;
		this.timeIn = timeIn;
		this.timeOut = timeOut;
		this.timecardHours = timecardHours;
		this.payCycleStartDate = payCycleStartDate;
		this.payCycleEndDate = payCycleEndDate;
		this.employeeName = employeeName;
		this.fileNumber = fileNumber;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Product [positionId=" + positionId + ", productStatus=" + productStatus + ", timeIn=" + timeIn
				+ ", timeOut=" + timeOut + ", timecardHours=" + timecardHours + ", payCycleStartDate="
				+ payCycleStartDate + ", payCycleEndDate=" + payCycleEndDate + ", employeeName=" + employeeName
				+ ", fileNumber=" + fileNumber + "]";
	}

	public void save(MultipartFile file) {
		// TODO Auto-generated method stub

	}

	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
