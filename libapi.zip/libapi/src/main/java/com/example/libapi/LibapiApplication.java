package com.example.libapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibapiApplication.class, args);
	}

}
